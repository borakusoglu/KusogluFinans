# Ödeme Log Tablosuna Yeni Alanlar Ekleme + Firebase Entegrasyonu — Teknik Uygulama Dokümanı

## Amaç

1. PrestaShop `ps_kdepo_payment_log` tablosuna 4 yeni alan eklemek
2. Her başarılı/başarısız ödeme işleminde verileri Firebase Firestore'a da yazmak
3. Tauri+React finans uygulamasının Firebase'den bu verileri okuması

### Hedef Veri Alanları

| Alan | DB Sütun Adı | Firestore Alan Adı | Tip | Açıklama |
|---|---|---|---|---|
| Sipariş No | `nestpay_order_id` | `orderId` | string | NestPay sipariş ID (zaten mevcut) |
| İşlem No | `trans_id` | `transId` | string | Banka işlem ID (zaten mevcut) |
| İşlem Durumu | `status` | `status` | string | success / failed / voided / refunded (zaten mevcut) |
| İşlem Tarihi | `date_add` | `dateAdd` | timestamp | İşlem tarihi (zaten mevcut) |
| Maskeli Kart No | `masked_card` | `maskedCard` | string | İlk 6 + son 4, ortası maskeli (YENİ) |
| Kart Markası | `card_brand` | `cardBrand` | string | VISA, Mastercard, Troy vb. (YENİ) |
| İşlem Tutarı | `amount` | `amount` | number | TL cinsinden tutar (zaten mevcut) |
| Provizyon No | `auth_code` | `authCode` | string | Banka onay kodu (zaten mevcut) |
| E-posta | `customer_email` | `customerEmail` | string | Müşteri e-postası (zaten mevcut) |
| Kartı Veren Banka | `card_bank` | `cardBank` | string | Ziraat, Garanti vb. (YENİ) |
| SKT Yılı | `card_expiry_year` | `cardExpiryYear` | string | Kartın son kullanma yılı (YENİ) |

> **PCI-DSS Notu:** Tam kart numarası hiçbir yerde saklanmaz. Sadece maskeli hali (ilk 6 + son 4) tutulur. Bu format Ziraat sanal POS panelinde de aynı şekilde gösterilmektedir.

---

## BÖLÜM A: Mevcut Sistem Mimarisi

Sistemde iki farklı ödeme akışı var. Her ikisinde de aynı `writeLog()` fonksiyonu çağrılarak `ps_kdepo_payment_log` tablosuna kayıt atılır.

### Akış 1: Doğrudan (Non-3D) Ödeme

```
[Kullanıcı Formu]
    │
    ▼
paymentapi.php → handlePayment()
    │
    ├─ validateRequest()     → Kart bilgileri doğrulanır
    ├─ sendToVirtualPos()    → NestPay XML API'ye kart bilgileri gönderilir
    │                          Banka CC5Response XML döner
    │                          NestpayXmlParser::parse() ile ayrıştırılır
    │
    ├─ Başarılı ise → handleSuccess() → writeLog() → DB'ye yazar
    └─ Başarısız ise → handleFailure() → writeLog() → DB'ye yazar
```

Bu akışta kart bilgileri (`cardNumber`, `expiryDate`) doğrudan `$data` dizisinde mevcuttur çünkü kullanıcı formdan göndermiştir.

### Akış 2: 3D Secure Ödeme (3D_PAY Modeli)

```
[Kullanıcı Formu]
    │
    ▼
paymentapi.php → handle3DInit()
    │
    ├─ Sipariş verileri JSON olarak ps_kdepo_3d_temp tablosuna kaydedilir
    ├─ Kart bilgileri + 3D parametreleri frontend'e döndürülür
    │
    ▼
[Frontend, bankaya 3D form POST eder → Banka 3D doğrulama sayfası açılır]
    │
    ▼
payment3dcallback.php → process3DCallback()
    │
    ├─ Banka POST ile callback parametrelerini gönderir
    ├─ ps_kdepo_3d_temp tablosundan sipariş verileri okunur
    ├─ Hash doğrulaması + mdStatus kontrolü yapılır
    │
    ├─ Başarılı ise → handleSuccessViaApi()
    │     └─ paymentapi.php'ye curl ile JSON POST atar (action: 3d_complete)
    │         └─ handle3DComplete() → handleSuccess() → writeLog() → DB'ye yazar
    │
    └─ Başarısız ise → logAndRedirect()
          └─ paymentapi.php'ye curl ile JSON POST atar (action: 3d_fail)
              └─ handle3DFail() → handleFailure() → writeLog() → DB'ye yazar
```

**Kritik nokta:** 3D akışında kart bilgileri `handle3DInit()`'te bankaya gönderilir. Callback'te banka kart bilgilerini geri döndürmez. Bu yüzden `handle3DInit()`'te `save3DOrderData()` ile temp tabloya kaydedilen JSON'a ihtiyacımız var.

---

## BÖLÜM B: PrestaShop Tarafı Değişiklikler (PHP)

### Değişiklik 1: Veritabanı Migration — `kdepo_tahsilat.php`

`migratePaymentLogTable()` fonksiyonundaki `$columns` dizisine 4 yeni sütun eklenmeli:

**Dosya:** `modules/kdepo_tahsilat/kdepo_tahsilat.php`
**Fonksiyon:** `migratePaymentLogTable()`

Mevcut `$columns` dizisine şunlar eklenmeli:

```php
'masked_card'       => 'VARCHAR(30) DEFAULT NULL',
'card_brand'        => 'VARCHAR(20) DEFAULT NULL',
'card_bank'         => 'VARCHAR(100) DEFAULT NULL',
'card_expiry_year'  => 'VARCHAR(4) DEFAULT NULL',
```

Ayrıca `createPaymentLogTable()` fonksiyonundaki CREATE TABLE SQL'ine de aynı sütunlar eklenmeli (yeni kurulumlar için):

```sql
`masked_card` VARCHAR(30) DEFAULT NULL,
`card_brand` VARCHAR(20) DEFAULT NULL,
`card_bank` VARCHAR(100) DEFAULT NULL,
`card_expiry_year` VARCHAR(4) DEFAULT NULL,
```

Bu sütunlar `nestpay_order_id` satırından sonra, `PRIMARY KEY` satırından önce eklenmeli.

---

### Değişiklik 2: writeLog Fonksiyonu — `paymentapi.php`

`writeLog()` fonksiyonundaki `$db->insert('kdepo_payment_log', [...])` dizisine 4 yeni alan eklenmeli:

**Dosya:** `modules/kdepo_tahsilat/controllers/front/paymentapi.php`
**Fonksiyon:** `writeLog()`

Mevcut insert dizisinin sonuna (`nestpay_order_id` satırından sonra) şunlar eklenmeli:

```php
'masked_card'      => !empty($data['maskedCard']) ? pSQL($data['maskedCard']) : null,
'card_brand'       => !empty($data['cardBrand']) ? pSQL($data['cardBrand']) : null,
'card_bank'        => !empty($data['cardBank']) ? pSQL($data['cardBank']) : null,
'card_expiry_year' => !empty($data['cardExpiryYear']) ? pSQL($data['cardExpiryYear']) : null,
```

---

### Değişiklik 3: 3D Init'te SKT Yılını Temp Tabloya Kaydetme — `paymentapi.php`

`handle3DInit()` fonksiyonunda `save3DOrderData()` çağrılmadan önce oluşturulan JSON'a `cardExpiryYear` eklenmeli.

**Dosya:** `modules/kdepo_tahsilat/controllers/front/paymentapi.php`
**Fonksiyon:** `handle3DInit()`

Mevcut kodda şu satırlar var:

```php
$expiryParts = explode('/', $expiryDate);
$expMonth = $expiryParts[0];
$expYear  = $expiryParts[1];
```

`$expYear` değeri 2 haneli olabilir (ör: `32`). 4 haneli yıla çevirmek için:

```php
$fullYear = strlen($expYear) === 2 ? '20' . $expYear : $expYear;
```

Sonra `$orderDataJson = json_encode([...])` dizisine şu satır eklenmeli (`cardBrand` satırından sonra):

```php
'cardExpiryYear' => $fullYear,
```

---

### Değişiklik 4: Doğrudan Ödemede Kart Verilerini $data'ya Ekleme — `paymentapi.php`

`handlePayment()` fonksiyonunda `sendToVirtualPos()` çağrıldıktan sonra, `handleSuccess()` veya `handleFailure()` çağrılmadan önce, `$data` dizisine maskeli kart ve SKT yılı eklenmeli.

**Dosya:** `modules/kdepo_tahsilat/controllers/front/paymentapi.php`
**Fonksiyon:** `handlePayment()`

`sendToVirtualPos()` çağrısından sonra, sonuç kontrolünden önce şu satırlar eklenmeli:

```php
// Maskeli kart oluştur (ilk 6 + son 4)
$cardNum = preg_replace('/[\s\-]/', '', $data['cardNumber'] ?? '');
if (strlen($cardNum) >= 10) {
    $data['maskedCard'] = substr($cardNum, 0, 6) . ' **** ' . substr($cardNum, -4);
} else {
    $data['maskedCard'] = '';
}

// SKT yılını çıkar
$expiryParts = explode('/', $data['expiryDate'] ?? '');
if (count($expiryParts) >= 2) {
    $yr = trim($expiryParts[1]);
    $data['cardExpiryYear'] = strlen($yr) === 2 ? '20' . $yr : $yr;
} else {
    $data['cardExpiryYear'] = '';
}
```

> **Not:** `cardBank` ve `cardBrand` alanları zaten frontend'den `$data` içinde gelmektedir (BIN lookup sonucu). Ek bir işlem gerekmez.

---

### Değişiklik 5: 3D Callback'te Verilerin API'ye Taşınması — `payment3dcallback.php`

**Dosya:** `modules/kdepo_tahsilat/controllers/front/payment3dcallback.php`

#### 5a. `handleSuccessViaApi()` fonksiyonunda:

`maskedCard` zaten oluşturuluyor. `$data['maskedCard'] = $maskedCard;` satırından sonra şu satır eklenmeli:

```php
$data['cardExpiryYear'] = $orderData['cardExpiryYear'] ?? '';
```

#### 5b. `logAndRedirect()` fonksiyonunda:

Mevcut `$data` dizisine şu alanlar eklenmeli:

```php
'maskedCard'      => '',
'cardBank'        => $orderData['cardBank'] ?? '',
'cardBrand'       => $orderData['cardBrand'] ?? '',
'cardExpiryYear'  => $orderData['cardExpiryYear'] ?? '',
```

---

## BÖLÜM C: Firebase Entegrasyonu (PHP → Firestore)

### Mimari

```
PrestaShop (PHP)                          Tauri+React Finans Uygulaması
─────────────────                         ─────────────────────────────
                                          
handleSuccess()                           Firebase SDK (JS)
    │                                         │
    ├─ writeLog() → MySQL                     ├─ Firestore'dan okur
    │                                         │   collection: "payment_logs"
    └─ writeToFirebase() [YENİ]               ├─ Real-time listener veya
         │                                    │   one-time fetch
         ├─ Firebase REST API                 └─ Tablo/liste olarak gösterir
         │   veya                          
         ├─ Firebase Admin SDK (PHP)       
         └─ Firestore'a yazar             
              collection: "payment_logs"   
```

### Yöntem: Firebase REST API (Önerilen — PHP tarafı için en basit)

PrestaShop PHP'den Firestore'a yazmak için Firebase Admin SDK (PHP) kullanılabilir ama en basit yöntem Firestore REST API'dir. Ek composer paketi gerektirmez, sadece bir Service Account JSON dosyası ve cURL yeterlidir.

### Adım 1: Firebase Service Account Oluşturma

1. Firebase Console → Proje Ayarları → Hizmet Hesapları (Service Accounts)
2. "Yeni özel anahtar oluştur" (Generate new private key) tıklayın
3. İndirilen JSON dosyasını sunucuya yükleyin:
   `modules/kdepo_tahsilat/config/firebase-service-account.json`
4. Bu dosyanın web'den erişilemez olduğundan emin olun (.htaccess veya nginx config ile)

**Güvenlik:** Bu dosya asla git'e eklenmemeli. `.gitignore`'a ekleyin:
```
modules/kdepo_tahsilat/config/firebase-service-account.json
```

### Adım 2: Firebase Helper Sınıfı — `FirestoreWriter.php`

**Yeni dosya:** `modules/kdepo_tahsilat/classes/FirestoreWriter.php`

Bu sınıf şunları yapmalı:

1. Service Account JSON'dan JWT token oluşturur (Google OAuth2)
2. Firestore REST API'ye document yazma isteği gönderir
3. `writeLog()` fonksiyonundan çağrılır

#### JWT Token Oluşturma Mantığı:

```
Service Account JSON'dan:
  - client_email (iss ve sub claim'leri)
  - private_key (JWT imzalama)
  - project_id (Firestore URL'i)

JWT Header: {"alg": "RS256", "typ": "JWT"}
JWT Payload: {
  "iss": client_email,
  "sub": client_email,
  "aud": "https://oauth2.googleapis.com/token",
  "iat": now,
  "exp": now + 3600,
  "scope": "https://www.googleapis.com/auth/datastore"
}

İmzalanmış JWT → Google OAuth2 token endpoint'ine POST
→ Access token alınır (1 saat geçerli)
→ Bu token ile Firestore REST API çağrılır
```

#### Firestore REST API Yazma:

```
POST https://firestore.googleapis.com/v1/projects/{PROJECT_ID}/databases/(default)/documents/payment_logs

Headers:
  Authorization: Bearer {ACCESS_TOKEN}
  Content-Type: application/json

Body: Firestore document formatında veri (aşağıda detaylı)
```

#### Sınıf Yapısı:

```php
class FirestoreWriter
{
    private $projectId;
    private $clientEmail;
    private $privateKey;
    private $accessToken;
    private $tokenExpiry;

    public function __construct()
    {
        // Service account JSON'ı oku
        $configPath = _PS_MODULE_DIR_ . 'kdepo_tahsilat/config/firebase-service-account.json';
        $config = json_decode(file_get_contents($configPath), true);
        
        $this->projectId   = $config['project_id'];
        $this->clientEmail = $config['client_email'];
        $this->privateKey  = $config['private_key'];
    }

    // JWT oluştur → Google'dan access token al
    private function getAccessToken(): string { ... }

    // Firestore'a document yaz
    public function writePaymentLog(array $data): bool { ... }
}
```

### Adım 3: Firestore Document Yapısı

**Collection:** `payment_logs`
**Document ID:** `{nestpay_order_id}` (sipariş numarası, benzersiz)

```json
{
  "orderId": "KDP-20260325-143022-A7B3",
  "transId": "26083KtRI00032457",
  "status": "success",
  "dateAdd": "2026-03-25T14:30:22Z",
  "maskedCard": "4543 60** **** 4059",
  "cardBrand": "VISA",
  "amount": 1250.00,
  "authCode": "P43567",
  "customerEmail": "[email]",
  "cardBank": "Ziraat Bankası",
  "cardExpiryYear": "2032",
  "customerFirstname": "Ad",
  "customerLastname": "Soyad",
  "companyName": "Firma Adı",
  "referenceNumber": "REF-20260325-143022",
  "description": "Açıklama",
  "procReturnCode": "00",
  "hostRefNum": "326814367541",
  "transactionType": "Auth",
  "errorCode": null,
  "errorMessage": null,
  "collectorUserId": 5,
  "instalment": 1,
  "createdAt": "SERVER_TIMESTAMP"
}
```

### Adım 4: writeLog() Fonksiyonuna Firebase Yazma Ekleme

`paymentapi.php` → `writeLog()` fonksiyonunda, MySQL insert'ten sonra Firebase yazma eklenmeli:

```php
// Mevcut MySQL insert'ten sonra:
try {
    require_once _PS_MODULE_DIR_ . 'kdepo_tahsilat/classes/FirestoreWriter.php';
    
    $firestore = new FirestoreWriter();
    $firestore->writePaymentLog([
        'orderId'           => $posResult['nestpayOrderId'] ?? '',
        'transId'           => $posResult['transactionId'] ?? '',
        'status'            => $status,
        'dateAdd'           => date('c'), // ISO 8601 format
        'maskedCard'        => $data['maskedCard'] ?? '',
        'cardBrand'         => $data['cardBrand'] ?? '',
        'amount'            => (float) $amount,
        'authCode'          => $posResult['authCode'] ?? '',
        'customerEmail'     => $data['email'] ?? '',
        'cardBank'          => $data['cardBank'] ?? '',
        'cardExpiryYear'    => $data['cardExpiryYear'] ?? '',
        'customerFirstname' => $data['firstName'] ?? '',
        'customerLastname'  => $data['lastName'] ?? '',
        'companyName'       => $data['companyName'] ?? '',
        'referenceNumber'   => $referenceNumber ?? '',
        'description'       => $data['description'] ?? '',
        'procReturnCode'    => $posResult['procReturnCode'] ?? '',
        'hostRefNum'        => $posResult['hostRefNum'] ?? '',
        'transactionType'   => $posResult['transactionType'] ?? '',
        'errorCode'         => $errorCode ?? '',
        'errorMessage'      => $errorMessage ?? '',
        'collectorUserId'   => (int) ($data['collectorUserId'] ?? 0),
        'instalment'        => (int) ($data['instalment'] ?? 0),
    ]);
} catch (\Exception $e) {
    // Firebase hatası ödeme akışını bozmamalı — sadece logla
    PrestaShopLogger::addLog(
        'kdepo_tahsilat: Firebase yazma hatası — ' . $e->getMessage(),
        2, null, 'Kdepo_Tahsilat'
    );
}
```

> **Önemli:** Firebase yazma hatası ödeme işlemini engellememelidir. try-catch içinde tutulmalı, hata sadece loglanmalıdır. MySQL ana veri kaynağı olmaya devam eder.

---

## BÖLÜM D: Tauri+React Finans Uygulaması Tarafı

### Firebase SDK Kurulumu (React)

```bash
npm install firebase
```

### Firebase Config

```typescript
// src/lib/firebase.ts
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "...",
  authDomain: "...",
  projectId: "AYNI_PROJECT_ID",  // PHP tarafıyla aynı proje
  storageBucket: "...",
  messagingSenderId: "...",
  appId: "..."
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
```

### Firestore'dan Veri Okuma

```typescript
// src/services/paymentService.ts
import { collection, query, orderBy, limit, getDocs, where, Timestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';

export interface PaymentLog {
  orderId: string;          // Sipariş No
  transId: string;          // İşlem No
  status: string;           // İşlem Durumu
  dateAdd: string;          // İşlem Tarihi
  maskedCard: string;       // Kredi Kartı No (maskeli)
  cardBrand: string;        // Kart Markası
  amount: number;           // İşlem Tutarı
  authCode: string;         // Provizyon No
  customerEmail: string;    // E-posta
  cardBank: string;         // Banka
  cardExpiryYear: string;   // SKT Yılı
  // Ek alanlar
  customerFirstname: string;
  customerLastname: string;
  companyName: string;
  referenceNumber: string;
  description: string;
  procReturnCode: string;
  hostRefNum: string;
  transactionType: string;
  errorCode: string | null;
  errorMessage: string | null;
  collectorUserId: number;
  instalment: number;
}

// Tüm ödeme loglarını çek (son 100)
export async function getPaymentLogs(limitCount = 100): Promise<PaymentLog[]> {
  const q = query(
    collection(db, 'payment_logs'),
    orderBy('dateAdd', 'desc'),
    limit(limitCount)
  );
  
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => doc.data() as PaymentLog);
}

// Tarih aralığına göre filtrele
export async function getPaymentLogsByDateRange(
  startDate: Date,
  endDate: Date
): Promise<PaymentLog[]> {
  const q = query(
    collection(db, 'payment_logs'),
    where('dateAdd', '>=', startDate.toISOString()),
    where('dateAdd', '<=', endDate.toISOString()),
    orderBy('dateAdd', 'desc')
  );
  
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => doc.data() as PaymentLog);
}

// Duruma göre filtrele (success / failed)
export async function getPaymentLogsByStatus(
  status: string
): Promise<PaymentLog[]> {
  const q = query(
    collection(db, 'payment_logs'),
    where('status', '==', status),
    orderBy('dateAdd', 'desc')
  );
  
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => doc.data() as PaymentLog);
}
```

### Firestore Güvenlik Kuralları

Tauri uygulamasında Firebase Auth kullanıyorsanız:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // payment_logs: sadece authenticated kullanıcılar okuyabilir
    // yazma sadece PHP backend'den (service account) yapılır
    match /payment_logs/{logId} {
      allow read: if request.auth != null;
      allow write: if false; // Client'tan yazma yasak
    }
  }
}
```

Eğer Firebase Auth kullanmıyorsanız ve sadece Tauri desktop uygulamasıysa, IP kısıtlaması veya custom token ile güvenlik sağlanabilir.

### Firestore Index Gereksinimleri

Aşağıdaki composite index'ler Firebase Console'dan veya `firestore.indexes.json` ile oluşturulmalı:

```json
{
  "indexes": [
    {
      "collectionGroup": "payment_logs",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "status", "order": "ASCENDING" },
        { "fieldPath": "dateAdd", "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "payment_logs",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "dateAdd", "order": "DESCENDING" }
      ]
    }
  ]
}
```

---

## BÖLÜM E: Veri Akış Özeti (Tüm Değişiklikler Sonrası)

### Doğrudan Ödeme:

```
Frontend formu → $data içinde cardNumber, expiryDate, cardBank, cardBrand var
    │
    ▼
handlePayment() → maskedCard ve cardExpiryYear hesaplanıp $data'ya eklenir [YENİ]
    │
    ▼
handleSuccess/handleFailure()
    ├─ writeLog() → 4 yeni alan MySQL'e yazılır [YENİ]
    └─ writeToFirebase() → Tüm alanlar Firestore'a yazılır [YENİ]
```

### 3D Secure Ödeme:

```
Frontend formu → handle3DInit()
    │
    ├─ cardExpiryYear hesaplanıp temp JSON'a eklenir [YENİ]
    │  (cardBank, cardBrand, cardNumber zaten temp JSON'da var)
    │
    ▼
Banka callback → process3DCallback() → temp JSON okunur
    │
    ├─ Başarılı → handleSuccessViaApi()
    │     ├─ maskedCard zaten oluşturuluyor (mevcut kod)
    │     ├─ cardExpiryYear orderData'dan alınıp $data'ya eklenir [YENİ]
    │     ├─ cardBank, cardBrand zaten $data'da (mevcut kod)
    │     └─ API'ye gönderilir → handle3DComplete() → handleSuccess()
    │           ├─ writeLog() → MySQL [YENİ alanlar dahil]
    │           └─ writeToFirebase() → Firestore [YENİ]
    │
    └─ Başarısız → logAndRedirect()
          ├─ cardBank, cardBrand, cardExpiryYear $data'ya eklenir [YENİ]
          └─ API'ye gönderilir → handle3DFail() → handleFailure()
                ├─ writeLog() → MySQL [YENİ alanlar dahil]
                └─ writeToFirebase() → Firestore [YENİ]
```

### Tauri+React Okuma:

```
Tauri+React Finans Uygulaması
    │
    ├─ Firebase JS SDK ile Firestore'a bağlanır
    ├─ "payment_logs" collection'ından query yapar
    ├─ Filtreleme: tarih aralığı, durum, kart markası vb.
    └─ Tablo/liste olarak gösterir
```

---

## BÖLÜM F: Maskeleme Formatı

Kart numarası maskeleme formatı Ziraat sanal POS paneli ile uyumludur:

| Kaynak | Format | Örnek |
|---|---|---|
| Ziraat POS Paneli | İlk 4 + kısmi + son 4 | `4543 60** **** 4059` |
| Mevcut Sistem (handleSuccessViaApi) | İlk 6 + *** + son 4 | `454360 *** 4059` |

Ziraat formatına uyumlu hale getirmek için maskeleme kodu:

```php
// Mevcut:
$maskedCard = substr($cardNum, 0, 6) . ' *** ' . substr($cardNum, -4);

// Ziraat formatı:
$maskedCard = substr($cardNum, 0, 4) . ' ' . substr($cardNum, 4, 2) . '** **** ' . substr($cardNum, -4);
```

---

## BÖLÜM G: Test Kontrol Listesi

### PHP Tarafı:
1. Modülü PrestaShop admin panelinden resetleyin → migration çalışır, yeni sütunlar eklenir
2. `firebase-service-account.json` dosyasını `modules/kdepo_tahsilat/config/` altına koyun
3. Doğrudan ödeme yapın → MySQL'de 4 yeni alan dolu + Firestore'da document oluşmuş olmalı
4. 3D Secure ödeme yapın → aynı kontrol
5. Başarısız ödeme yapın → Firestore'da `status: "failed"` document oluşmalı

### Tauri+React Tarafı:
1. Firebase config'i doğru proje ID ile ayarlayın
2. `getPaymentLogs()` çağrısı ile verilerin geldiğini doğrulayın
3. Tarih ve durum filtrelerini test edin
4. Firestore güvenlik kurallarını deploy edin

### SQL Doğrulama Sorgusu (MySQL):

```sql
SELECT
    nestpay_order_id    AS siparis_no,
    trans_id            AS islem_no,
    status              AS islem_durumu,
    date_add            AS islem_tarihi,
    masked_card         AS kredi_karti_no,
    card_brand          AS kart_markasi,
    amount              AS islem_tutari,
    auth_code           AS provizyon_no,
    customer_email      AS eposta,
    card_bank           AS banka,
    card_expiry_year    AS skt_yili
FROM ps_kdepo_payment_log
ORDER BY date_add DESC;
```

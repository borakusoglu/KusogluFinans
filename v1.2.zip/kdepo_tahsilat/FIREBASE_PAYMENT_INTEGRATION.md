# Firebase Realtime Database — Ödeme Logları Entegrasyonu

## Genel Bakış

PrestaShop ödeme modülü (`kdepo_tahsilat`), her başarılı veya başarısız ödeme işleminde verileri hem MySQL'e hem de Firebase Realtime Database'e yazar. Tauri+React finans uygulaması Firebase'den bu verileri okur.

```
PrestaShop (PHP)                          Tauri+React Finans Uygulaması
─────────────────                         ─────────────────────────────

Ödeme tamamlanır                          Firebase JS SDK
    │                                         │
    ├─ writeLog() → MySQL (ana kayıt)         ├─ Realtime Database'den okur
    │                                         │   path: /payment_logs/{orderId}
    └─ FirebaseWriter → REST API              ├─ Real-time listener veya
         │                                    │   one-time fetch
         └─ Firebase RTDB'ye yazar            └─ Tablo/liste olarak gösterir
              path: /payment_logs/{orderId}
```

---

## Firebase Projesi Bilgileri

```
Proje ID:     kusoglufinans
Database URL: https://kusoglufinans-default-rtdb.europe-west1.firebasedatabase.app
Region:       europe-west1
```

---

## Firebase Realtime Database Yapısı

### Yol (Path)

```
/payment_logs/{orderId}
```

`orderId` = NestPay sipariş numarası (ör: `KDP-20260325-143022-A7B3`). Her ödeme işlemi için benzersizdir.

### Örnek Veri

```json
{
  "payment_logs": {
    "KDP-20260325-143022-A7B3": {
      "orderId": "KDP-20260325-143022-A7B3",
      "transId": "26083KtRI00032457",
      "status": "success",
      "dateAdd": "2026-03-25T14:30:22+03:00",
      "maskedCard": "4543 60** **** 4059",
      "cardBrand": "VISA",
      "amount": 1250.00,
      "authCode": "P43567",
      "customerEmail": "musteri@example.com",
      "cardBank": "Ziraat Bankası",
      "cardExpiryYear": "2032",
      "customerFirstname": "Ad",
      "customerLastname": "Soyad",
      "companyName": "Firma Adı",
      "referenceNumber": "REF-20260325-143022",
      "description": "Sipariş açıklaması",
      "procReturnCode": "00",
      "hostRefNum": "326814367541",
      "transactionType": "Auth",
      "errorCode": "",
      "errorMessage": "",
      "collectorUserId": 5,
      "instalment": 1,
      "createdAt": "2026-03-25T11:30:22Z"
    }
  }
}
```

### Alan Açıklamaları

| Alan | Tip | Açıklama | Örnek |
|---|---|---|---|
| `orderId` | string | NestPay sipariş numarası (benzersiz) | `KDP-20260325-143022-A7B3` |
| `transId` | string | Banka işlem numarası | `26083KtRI00032457` |
| `status` | string | İşlem durumu: `success`, `failed`, `voided`, `refunded` | `success` |
| `dateAdd` | string | İşlem tarihi (ISO 8601) | `2026-03-25T14:30:22+03:00` |
| `maskedCard` | string | Maskeli kart numarası (ilk 4 + 2 hane + son 4) | `4543 60** **** 4059` |
| `cardBrand` | string | Kart markası | `VISA`, `Mastercard`, `Troy` |
| `amount` | number | İşlem tutarı (TL) | `1250.00` |
| `authCode` | string | Banka provizyon/onay kodu | `P43567` |
| `customerEmail` | string | Müşteri e-posta adresi | `musteri@example.com` |
| `cardBank` | string | Kartı veren banka | `Ziraat Bankası` |
| `cardExpiryYear` | string | Kart son kullanma yılı | `2032` |
| `customerFirstname` | string | Müşteri adı | `Ad` |
| `customerLastname` | string | Müşteri soyadı | `Soyad` |
| `companyName` | string | Firma adı | `Firma Adı` |
| `referenceNumber` | string | Sistem referans numarası | `REF-20260325-143022` |
| `description` | string | İşlem açıklaması | `Sipariş açıklaması` |
| `procReturnCode` | string | Banka işlem sonuç kodu (`00` = başarılı) | `00` |
| `hostRefNum` | string | Banka referans numarası | `326814367541` |
| `transactionType` | string | İşlem tipi | `Auth` |
| `errorCode` | string | Hata kodu (başarısız işlemlerde) | `05` veya `""` |
| `errorMessage` | string | Hata mesajı (başarısız işlemlerde) | `Kart limiti yetersiz` veya `""` |
| `collectorUserId` | number | Tahsilat yapan kullanıcı ID | `5` |
| `instalment` | number | Taksit sayısı (0 veya 1 = peşin) | `1` |
| `createdAt` | string | Firebase'e yazılma zamanı (UTC) | `2026-03-25T11:30:22Z` |

### Başarısız İşlem Örneği

```json
{
  "orderId": "KDP-20260325-150100-X9C2",
  "transId": "",
  "status": "failed",
  "dateAdd": "2026-03-25T15:01:00+03:00",
  "maskedCard": "",
  "cardBrand": "Mastercard",
  "amount": 500.00,
  "authCode": "",
  "customerEmail": "musteri@example.com",
  "cardBank": "Garanti Bankası",
  "cardExpiryYear": "2028",
  "customerFirstname": "Ad",
  "customerLastname": "Soyad",
  "companyName": "Firma Adı",
  "referenceNumber": "",
  "description": "",
  "procReturnCode": "05",
  "hostRefNum": "",
  "transactionType": "Auth",
  "errorCode": "05",
  "errorMessage": "Kart limiti yetersiz",
  "collectorUserId": 3,
  "instalment": 0,
  "createdAt": "2026-03-25T12:01:00Z"
}
```

> **Not:** Başarısız 3D işlemlerde `maskedCard` boş olabilir (banka kart bilgisini geri döndürmez). Diğer alanlar (`cardBank`, `cardBrand`, `cardExpiryYear`) dolu gelir.

---

## PHP Tarafı (PrestaShop) — Zaten Entegre Edildi

### Dosya: `modules/kdepo_tahsilat/classes/FirebaseWriter.php`

Bu sınıf:
1. Google Service Account JSON'dan JWT token oluşturur
2. Google OAuth2 endpoint'inden access token alır
3. Firebase Realtime Database REST API'ye PUT isteği ile veri yazar
4. Token'ı cache'ler (1 saat geçerli)

### Çağrıldığı Yer: `paymentapi.php` → `writeLog()`

Her `writeLog()` çağrısında MySQL'e yazdıktan sonra Firebase'e de yazar. Firebase hatası ödeme akışını bozmaz (try-catch içinde, sadece loglanır).

### Gerekli Kurulum (Sunucu Tarafı)

1. Firebase Console → Proje Ayarları → Hizmet Hesapları → "Yeni özel anahtar oluştur"
2. İndirilen JSON dosyasını şuraya koyun:
   ```
   modules/kdepo_tahsilat/config/firebase-service-account.json
   ```
3. Bu dosyanın web'den erişilemez olduğundan emin olun
4. `.gitignore`'a ekleyin:
   ```
   modules/kdepo_tahsilat/config/firebase-service-account.json
   ```

---

## Tauri+React Tarafı — Okuma Rehberi

### Firebase Config

```typescript
const firebaseConfig = {
  apiKey: "AIzaSyDgahl8hNQU9hkuAoOnHR9T16LZFYlVFm4",
  authDomain: "kusoglufinans.firebaseapp.com",
  databaseURL: "https://kusoglufinans-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "kusoglufinans",
  storageBucket: "kusoglufinans.firebasestorage.app",
  messagingSenderId: "827527161814",
  appId: "1:827527161814:web:af21672a78e5f022c4e677",
  measurementId: "G-5T723CWK3G"
};
```

### Veri Okuma (Firebase Realtime Database)

```typescript
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, query, orderByChild, get, onValue } from 'firebase/database';

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// --- TypeScript Interface ---
interface PaymentLog {
  orderId: string;
  transId: string;
  status: 'success' | 'failed' | 'voided' | 'refunded';
  dateAdd: string;
  maskedCard: string;
  cardBrand: string;
  amount: number;
  authCode: string;
  customerEmail: string;
  cardBank: string;
  cardExpiryYear: string;
  customerFirstname: string;
  customerLastname: string;
  companyName: string;
  referenceNumber: string;
  description: string;
  procReturnCode: string;
  hostRefNum: string;
  transactionType: string;
  errorCode: string;
  errorMessage: string;
  collectorUserId: number;
  instalment: number;
  createdAt: string;
}

// --- Tüm logları çek (one-time) ---
async function getAllPaymentLogs(): Promise<PaymentLog[]> {
  const logsRef = ref(db, 'payment_logs');
  const q = query(logsRef, orderByChild('dateAdd'));
  const snapshot = await get(q);

  if (!snapshot.exists()) return [];

  const data = snapshot.val();
  return Object.values(data) as PaymentLog[];
}

// --- Real-time listener (canlı güncelleme) ---
function onPaymentLogsChange(callback: (logs: PaymentLog[]) => void) {
  const logsRef = ref(db, 'payment_logs');
  
  onValue(logsRef, (snapshot) => {
    if (!snapshot.exists()) {
      callback([]);
      return;
    }
    const data = snapshot.val();
    const logs = Object.values(data) as PaymentLog[];
    // Tarihe göre sırala (en yeni önce)
    logs.sort((a, b) => b.dateAdd.localeCompare(a.dateAdd));
    callback(logs);
  });
}
```

### İstenen 11 Alanı Gösteren Tablo İçin Mapping

```typescript
// Tauri uygulamasında tablo sütunları:
const columns = [
  { key: 'orderId',         label: 'Sipariş No' },
  { key: 'transId',         label: 'İşlem No' },
  { key: 'status',          label: 'İşlem Durumu' },
  { key: 'dateAdd',         label: 'İşlem Tarihi' },
  { key: 'maskedCard',      label: 'Kredi Kartı No' },
  { key: 'cardBrand',       label: 'Kart Markası' },
  { key: 'amount',          label: 'İşlem Tutarı' },
  { key: 'authCode',        label: 'Provizyon No' },
  { key: 'customerEmail',   label: 'E-posta' },
  { key: 'cardBank',        label: 'Banka' },
  { key: 'cardExpiryYear',  label: 'SKT Yılı' },
];
```

### Durum Gösterimi

```typescript
function formatStatus(status: string): string {
  const map: Record<string, string> = {
    'success':  'Başarılı',
    'failed':   'Başarısız',
    'voided':   'İptal Edildi',
    'refunded': 'İade Edildi',
  };
  return map[status] || status;
}
```

### SKT Formatı (Ziraat Uyumlu)

```typescript
// cardExpiryYear: "2032" → gösterim: "**.2032"
function formatExpiry(year: string): string {
  return year ? `**.${year}` : '';
}
```

### Tutar Formatı

```typescript
// amount: 1250.00 → gösterim: "1.250,00 TL"
function formatAmount(amount: number): string {
  return amount.toLocaleString('tr-TR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }) + ' TL';
}
```

---

## Firebase Realtime Database Güvenlik Kuralları

Firebase Console → Realtime Database → Kurallar:

```json
{
  "rules": {
    "payment_logs": {
      ".read": "auth != null",
      ".write": false,
      ".indexOn": ["dateAdd", "status"]
    }
  }
}
```

> **Açıklama:**
> - `.read`: Sadece authenticated kullanıcılar okuyabilir
> - `.write`: false — client'tan yazma yasak (sadece PHP service account yazar)
> - `.indexOn`: `dateAdd` ve `status` alanlarına index, sıralama/filtreleme performansı için

Eğer Tauri uygulamasında Firebase Auth kullanmıyorsanız, geliştirme aşamasında geçici olarak:

```json
{
  "rules": {
    "payment_logs": {
      ".read": true,
      ".write": false,
      ".indexOn": ["dateAdd", "status"]
    }
  }
}
```

> **Uyarı:** Canlıya geçmeden önce mutlaka auth kuralını aktif edin.

---

## Özet: Dosya Listesi ve Değişiklikler

### Yeni Dosya:
| Dosya | Açıklama |
|---|---|
| `modules/kdepo_tahsilat/classes/FirebaseWriter.php` | Firebase RTDB'ye yazan PHP sınıfı |
| `modules/kdepo_tahsilat/config/firebase-service-account.json` | Google Service Account (manuel oluşturulacak) |

### Değiştirilen Dosyalar:
| Dosya | Değişiklik |
|---|---|
| `modules/kdepo_tahsilat/kdepo_tahsilat.php` | DB migration'a 4 yeni sütun eklendi |
| `modules/kdepo_tahsilat/controllers/front/paymentapi.php` | `writeLog()`'a 4 yeni alan + Firebase yazma eklendi, `handlePayment()`'te maskedCard/cardExpiryYear hesaplama eklendi, `handle3DInit()`'te cardExpiryYear temp'e kaydediliyor |
| `modules/kdepo_tahsilat/controllers/front/payment3dcallback.php` | `handleSuccessViaApi()`'ye cardExpiryYear eklendi, `logAndRedirect()`'e kart bilgileri eklendi, maskeleme formatı Ziraat uyumlu yapıldı |
